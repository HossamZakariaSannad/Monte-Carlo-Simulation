1 - Click Montecarlo . exe to run the program.

2 - fill (Items) coloumn and (Probability) coloumn .

3 - Click Calculate for execution .

4 - Click Exist to Quit .



tip : probability coloumn support 

percentage numbers like (10,20,30,40,...)
float      numbers like (0.1, 0.2, 0.25 , 0.5 , .8 , ...)



Hope You a Nice Day ! 


Errors may happen : 
To see Full Program Screen            set monitor screen to this resolution (1920 x 1080) 
If program screen is too large        set monitor screen to this resolution (1920 x 1080) 



Programs must be installed : 
https://javadl.oracle.com/webapps/download/AutoDL?BundleId=242060_3d5a2bb8f8d4428bbe94aed7ec7ae784








